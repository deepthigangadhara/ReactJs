import {useState} from 'react'
import './Product.css'
import DummyData from '../ProductData'
import React from 'react'
import { render } from '@testing-library/react'

class Product extends React.Component
{         
 // const [products,setProducts] = useState(DummyData) 
 // const [priceRange,setPriceRange] = useState(0)

  /*const [companies,setCompanies] = useState([...new Set(DummyData.map(ob=>ob.company))])

    var arr = DummyData.map(ob=>ob.price)
    const [priceMinMax,setPriceMinMax] = useState({
        min : Math.min(...arr),
        max : Math.max(...arr)
    })*/
    constructor(props){
        super(props)
        this.state={
            products: this.DummyData,
            priceRange : 0,
            companies : 
             setState([...new Set(this.DummyData.map(ob=>ob.company))]),
             priceMinMax : setState({...priceMinMax,
                min : Math.min(...arr),
                max : Math.max(...arr)
            })
         
        
        }
    }
    arr = this.DummyData.map(ob=>ob.price)
    
     fetchCategory = (event)=>
    {
        var category = event.target.innerHTML.toLowerCase()
        var filterData = this.DummyData.filter(prod=>category=='all'?true:prod.category==category)
        setState(...this.state.products,filterData)
        setState(...this.state.companies, [...new Set(filterData.map(ob=>ob.company))])
        var prices = filterData.map(ob=>ob.price)
        setState({priceMinMax,
            min : Math.min(...prices),
            max : Math.max(...prices)
        })
    }

 /* const addCart = (event)=>
  {
      var pid = event.target.getAttribute('data-id');        
  }       */     
  render(){
  return <div className='Product'>
         <div className='row'>
            <div className='col-lg-3 text-center filterdiv'> 
                <h2>All Category</h2>               
                <hr/>
                    <h5 onClick={this.fetchCategory}>All</h5> <br/>
                    <h5 onClick={this.fetchCategory}>TV</h5> <br/>
                    <h5 onClick={this.fetchCategory}>AC</h5><br/>
                    <h5 onClick={this.fetchCategory}>Fan</h5>    <br/>  
                      
                <hr/>
                <h2>Company</h2> 
                <hr/>
                {this.state.companies.map(com=>{
                    return <h5>{com}</h5>
                })}                 
                <hr/> 
               
                

                <h2>Price : <span style={{color:'red'}}>{this.state.priceRange}</span></h2>  
                <h4>Min: {this.state.priceMinMax.min} &nbsp; Max : {this.state.priceMinMax.max}</h4>              
                <hr/> 
                <input type="range"  
                onChange={(event)=>setPriceRange(event.target.value)} value={priceRange} min={priceMinMax.min} max={priceMinMax.max}/>             
            </div>
            <div className='col-lg-9'>
      <table className='table table-hovered'>
          <thead>
              <tr>
                  <th>S.No.</th>
                  <th>Image</th>
                  <th>Product Name</th>
                  <th>Company</th>
                  <th>Price</th>
                  <th>Discount</th>
                  <th>Operation</th>
              </tr>
          </thead>
          <tbody>
              {this.state.products.map((prod,index)=>
              {
                return <tr>
                    <td>{index+1}</td>
                    <td><img src={prod.image}/></td>
                    <td>{prod.name}</td>
                    <td>{prod.company}</td>
                    <td>{prod.price}</td>
                    <td>{prod.discount}</td>
                    <th>
                    <button onClick={()=>this.props.addProductToCart(prod.pid)}  className='btn btn-success'>Add Cart</button>
                     </th>
                </tr>
              })}
          </tbody>
      </table>
  </div>
  </div>
  </div>
}}
export default Product