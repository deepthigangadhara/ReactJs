import React from 'react'
export class First extends React.Component{
    render(){
        return <div>
            <h2>First Component</h2>
        </div>
    }
}
export class Second extends React.Component{
    render(){
        return <div>
            <h2>Second Component</h2>
        </div>
    }
}
export default class Third extends React.Component{
    render(){
        return <div>
            <h2>Third Component</h2>
        </div>
    }
}