import React from 'react'
import MyContext from './MyContext';

export default class Mobiles extends React.Component
{
   static contextType= MyContext;
   
    render()
    {
        return  <table align='center'border='1' cellPadding="10" cellSpacing="5">
        <thead><tr>
            <th>Name</th>
            <th>Company</th>
            <th>Price</th>
            <th>Discount</th>
            <th>Image</th>
            <th>Operation</th>
            </tr>
        </thead>
        <tbody>
        
            <tr>
            <td><img src="/imgs/m1.jpg"></img></td>
              <td>iPhone</td>
                <td>Apple</td>
                <td>70000</td>
                <td>10</td>
                <td><button>Add to Cart</button></td>
                
        </tr>
        </tbody>
        </table>
    }
}