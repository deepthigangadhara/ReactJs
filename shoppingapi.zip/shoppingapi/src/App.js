import React from 'react'
import MyContext from './MyContext';


import { BrowserRouter } from 'react-router-dom'
import Product from './Product';
import Mobiles from './Mobiles';

class App extends React.Component
{
    constructor()
    {
      super() 
      this.state={
        product:[
         {pname:"iPhone",company:"Apple", category:"Mobile", price: 70000, discount: 10, image:"/imgs/m1.jpg"},
         {pname:"Redmi 9",company:"Redmi", category:"Mobile", price: 20000, discount: 5, image:"/imgs/m2.jpg"},
         {pname:"IFB 1.5 Ton AC",company:"IFB", category:"Air Conditioner", price: 37000, discount: 25, image:"/imgs/ac1.jpg"},
         {pname:"Croma 1 Ton AC",company:"Croma", category:"Air Conditioner", price: 24000, discount: 35, image:"/imgs/ac2.jpg"},
         {pname:"SONY X74",company:"Sony", category:"TV", price: 63000, discount: 23, image:"/imgs/tv1.jpg"},
         {pname:"LG",company:"LG", category:"TV", price: 34000, discount: 18, image:"/imgs/tv2.jpg"}
        ]
      }  
    }
    render()
    {     
      return <div>
         <h1 style={{textAlign: 'center'}}>App Component</h1>
         <button>Show Cart</button>
         <hr/>
         <BrowserRouter>
         <MyContext.Provider value={{product:this.state.product}}>

        <Product />
        </MyContext.Provider>
        </BrowserRouter>
      
      </div>
    }
}


export default App;