import React from 'react'
//import MyContext from './MyContext';
import Mobiles from './Mobiles'
import AC from './AC';
import Tv from './Tv';
import {Link , Routes , Route} from 'react-router-dom'
export default class Product extends React.Component{
    render(){
        return <div>
            <h1 style={{textAlign: 'center'}}>Product Component</h1>
            <h2>Categories</h2>
            <Link to="/"> <h3><li>Mobiles</li></h3></Link>
            <Link to="/ac"> <h3><li>Air Conditioner</li></h3></Link>
            <Link to="/tv"> <h3><li>Tv</li></h3></Link>
            
            <Routes>
                <Route path="/" element={<Mobiles/>}/>
                <Route path="/ac" element={<AC/>}/>
                <Route path="/tv" element={<Tv/>}/>
             </Routes>  
            
        </div>
    }
}