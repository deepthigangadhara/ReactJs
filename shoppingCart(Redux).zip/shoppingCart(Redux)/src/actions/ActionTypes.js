export const ADD_CART = "addCart"
export const REMOVE_CART = "removeCart"
export const INCREMENT_CART = "incrementCart"
export const DECREMENT_CART = "decrementCart"


export const FILTER_CHANGE = "filterChange"