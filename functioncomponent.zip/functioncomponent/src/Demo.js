import Sample from "./Sample"

function Demo(props)
{
  return <div>
    <h2>Demo Component</h2>
    <b>{props.title}</b>
    <Sample/>
  </div>
}

export default Demo