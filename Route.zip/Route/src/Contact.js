import React from 'react'

export default class Contact extends React.Component
{
    render()
    {
        return <div>
            <h2>Contact Component</h2>
            <img src="/imgs/img3.jpg" />
        </div>
    }
}