var mongoose = require('mongoose');

function getConnection(callback)
{
    mongoose.connect('mongodb+srv://admin:deepthig2000@cluster0.pyjx7.mongodb.net/hosptaldb?retryWrites=true&w=majority');
    var conn = mongoose.connection;
 
    callback(conn)
}

module.exports = getConnection